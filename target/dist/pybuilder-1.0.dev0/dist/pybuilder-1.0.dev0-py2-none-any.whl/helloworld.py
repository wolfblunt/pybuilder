import sys
#hello
def helloworld(out):
	out.write('hello Aman')
	out.write('hello Apar')
	print("Hello World")

print("Hello Aman")
print("Hello Apar")
print("Hello Shashwat")
print("Hello Brother")
print("Hello Abhijit")
print("YEH!")
print("Hurray")
print("Hello sir")
print("Successful Build")
print("Good Job Aman")
print("Hello everyone 12345")


