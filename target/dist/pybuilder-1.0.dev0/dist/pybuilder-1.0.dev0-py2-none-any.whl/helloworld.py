import sys
def helloworld(out):
	out.write('hello Aman')
