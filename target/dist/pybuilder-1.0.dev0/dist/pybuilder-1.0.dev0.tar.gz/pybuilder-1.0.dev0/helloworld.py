import sys
#hello
def helloworld(out):
	out.write('hello meow')
	out.write('hello Aparna')
	print("Hello World")

print("Hello Aman")
print("Hello Apar")
print("Hello Shashwat")
print("Hello Brother")
print("Hello Abhijit")
print("YEH!")
print("Hurray")
print("Hello sir")
print("Successful Build")
print("Good Job Aman")
print("Hello Raghav")


