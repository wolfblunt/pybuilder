import sys
#hello
def helloworld(out):
	out.write('hello Aman')
	out.write('hello Apar')
